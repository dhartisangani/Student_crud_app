const express = require('express');
const fetchuser = require('../middleWare/fetchuser');
const router = express.Router();
const multer = require('multer');
const { addstudent, getAllStudents, getStudentByID, getStudentWithSerchandPagination, updateStudentwithID, deleteStudent } = require('../Controller/studentController');

// const storage = multer.diskStorage({
//     destination: './images',
//     filename: (req, file, callback) => {
//         callback(null, `image-${Date.now()}.${file.originalname}`);
//     },
// });

// const upload = multer({ storage });
const multerStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "public");
    },
    filename: (req, file, cb) => {
        const ext = file.mimetype.split("/")[1];
        cb(null, `images/admin-${file.fieldname}-${Date.now()}.${ext}`);
    },
});
const upload = multer({ storage: multerStorage });
// Add Student
// const upload = multer({ storage: storage });

router.post('/add', upload.single('imgUrl'), addstudent);

// Get StudentList 
router.get('/getstudents', getAllStudents)

// Get Student data with  _ID 
router.get('/:id', getStudentByID);

// Get Student with Search and Pagination 
router.get('', getStudentWithSerchandPagination);
// http://localhost:8080/api/student/all?search=$"'&page=$1&limit=$1

// Update Student with ID 
router.put('/update/:id', updateStudentwithID)

// Delete Student 
router.delete('/delete/:id', deleteStudent)

module.exports = router
